package com.hcl.test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;

import javax.crypto.BadPaddingException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public class SSHUtil {

	/****
	 * Description: For copy file from Hadoop to HPC outputToFile is null and
	 * fileToCat will be having the Cat file name present in Hadoop
	 * 
	 * @param session
	 * @param fileToCat
	 * @param outputToFile
	 * @param fileToMove
	 * @throws JSchException
	 * @throws InterruptedException
	 */

	public static void moveFile(Session session, InputStream fileToCat, OutputStream outputToFile, String fileToMove, boolean hashCheck)
			throws Exception {
		
		System.out.println("Start of moveFile method..");
		String putOrGet = null;

		// Hadoop to HPC copy
		String hash = null;
		System.out.println("fileToCat...."+fileToCat);
		if (fileToCat != null) {
			if (hashCheck) {
				hash = getHash(fileToCat);
				System.out.println("I am in movefile at Hash..."+hash);
			}
			putOrGet = "put";
		}

		// HPC to Hadoop copy
		if (outputToFile != null) {
			if (hashCheck) {
				hash = getHash(session, fileToMove);
				System.out.println("fileToMove.."+hash);
			}
			putOrGet = "get";
		}

		if (putOrGet != null) {
			ChannelExec channelExec = (ChannelExec) session.openChannel("exec");
			if (putOrGet.equals("get")) {
				channelExec.setOutputStream(outputToFile);
			} else {
				channelExec.setInputStream(fileToCat);
			}

			String command = "/boeing/sw/ecfd/bin/TransferFileHpcHdp " + putOrGet + " " + fileToMove;
			System.out.println("Going to run Command =="+command);
			channelExec.setCommand(command);
			channelExec.connect();
			System.out.println("command executed......");
			// HACK: there is an issue if you dont sleep for few milliseconds,
			// need to troubleshoot
			
			waitToCompleteTask(channelExec);
			
			//TODO: Please check this. While uncommenting this block the control is going into Catch block but no Exception is printed on console
			/*if(channelExec.getExitStatus() < 0){
				throw new Exception("channelExec.getExitStatus() = " + channelExec.getExitStatus());
			}	*/			

			System.out.println("channelExec.getExitStatus()="+channelExec.getExitStatus());
			channelExec.disconnect();
			
			System.out.println("End of moveFile method..");
		}

		if (hashCheck) {
			if (outputToFile != null) {
				String hash1 = getHash(outputToFile);
				//Commenting this line for the reverse copy flow...
				/*if (!hash1.equals(hash)) {
					throw new Exception("File is not copied properly");
				}*/
			}
			if (fileToCat != null) {
				String hash1 = getHash(session,fileToMove);
				System.out.println("at line 85..."+hash1);
				//TODO:  Offshore has to implement the input method for Hash
				//
				/*if (!hash1.equals(hash)) {
					throw new Exception("File is not copied properly");
				}*/
			}
		}
		
		System.out.println("End of moveFile method..After Hash method called....");
	}

	private static void waitToCompleteTask(ChannelExec channelExec) throws Exception
	{
		boolean channelClosed = false;
		do{
			Thread.sleep(20L);
			channelClosed = channelExec.isClosed();
		}while(channelClosed);
	}
	private static String getHash(Session session, String remoteFileName) throws Exception {
		// Need to implement below stuff
		// ssh �q -i /data/home/zh722e/id_rsa_zh722e zh722e@charon.cs.boeing.com
		// /boeing/sw/ecfd/bin/TransferFileHpcHdp hash
		// /home/z/zh722e/demo/10Feb/10Jan_2018/tar_test_loc/newdir/abc.tar
		ChannelExec channelExec = (ChannelExec) session.openChannel("exec");
		
		ByteArrayOutputStream hashDataStream = new ByteArrayOutputStream();

		channelExec.setOutputStream(hashDataStream);

		String command = "/boeing/sw/ecfd/bin/TransferFileHpcHdp hash " + remoteFileName;
		channelExec.setCommand(command);
		channelExec.connect();

		waitToCompleteTask(channelExec);

		channelExec.disconnect();
		
		return hashDataStream.toString(StandardCharsets.UTF_8.toString());
	}

	private static String getHash(InputStream fileToCat) {
		// TODO Auto-generated method stub
		return null;
	}

	private static String getHash(OutputStream localFileStream) {
		// Need to check with Josef on what is the Md5 hashing
		// TODO Auto-generated method stub
		return null;
	}
	public static Session getSFTPSessionWithPrivateKey(String privateKey)
            throws BadPaddingException, JSchException, IllegalArgumentException, IOException {
		System.out.println("Start of getSFTPSessionWithPrivateKey method....");

     String secKey = null;
     // Get the seckey to decrypt the private key
    
     Session session = null;
     JSch.setLogger(new DaProcessorLogger());
     JSch jsch = new JSch();
     // new changes
     session = jsch.getSession("zh722e", "charon.cs.boeing.com", 22);
     session.setConfig("StrictHostKeyChecking", "no");
     session.setConfig("PreferredAuthentications", "publickey,keyboard-interactive,password");
   
     System.out.println("privateKey>>>>...." + privateKey);
     /*String decrypedKey = ProcessorUtil.decrypt(privateKey, generateHashCode(secKey));
     System.out.println("This is decrptedkey =======> " + decrypedKey);
     */ 
     //jsch.addIdentity(privateKey);
     jsch.addIdentity("", privateKey.getBytes(), null, null);
    System.out.println("before session.isConnected()=" + session.isConnected());
     if (!session.isConnected()) {
            System.out.println("inside if statement session.isConnected()=" + session.isConnected());
            session.connect();
     }
     System.out.println("after if statement session.isConnected()=" + session.isConnected());
     System.out.println("End of getSFTPSessionWithPrivateKey method....");
     return session;
     
}

	public static class DaProcessorLogger implements com.jcraft.jsch.Logger {
        static java.util.Hashtable<Integer,String> name = new java.util.Hashtable<Integer,String>();
        static {
            name.put(new Integer(DEBUG), "DEBUG: ");
            name.put(new Integer(INFO), "INFO: ");
            name.put(new Integer(WARN), "WARN: ");
            name.put(new Integer(ERROR), "ERROR: ");
            name.put(new Integer(FATAL), "FATAL: ");
        }
        public boolean isEnabled(int level) {
            return true;
        }
        public void log(int level, String message) {
            System.err.print(name.get(new Integer(level)));
            System.err.println(message);
        }
    }
	
}
