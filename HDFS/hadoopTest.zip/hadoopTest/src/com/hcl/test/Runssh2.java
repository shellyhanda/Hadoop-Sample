package com.hcl.test;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import com.jcraft.jsch.Session;

public class Runssh2 {

	public static void main(String args[]) {
		try {
			System.out.println("Starting the code...");
			Configuration config = new Configuration();
			config.set("fs.defaultFS", "hdfs://BOEINGHDO4:8020");
			FileSystem fs = null;
			fs = FileSystem.get(config);
			Session session = null;

			Path hdfswritepath = new Path("/user/zh722e/local_solution.json");
			// Init output stream
			FSDataOutputStream outputStream = fs.create(hdfswritepath);
			session = SSHUtil.getSFTPSessionWithPrivateKey(args[0]);
			SSHUtil.moveFile(session, null, outputStream, "/home/z/zh722e/demo/10Feb/10Jan_2018/tar_test_loc/newdir/15Jan_2018.json", true);

			System.out.println("Copied in HDFS at /user/zh722e/local_solution.json....");
			fs.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("I m in Catch block...");
			e.printStackTrace();
		}

		System.out.println("Ending the code...");
		System.out.println("Program terminated!");
	}
}
