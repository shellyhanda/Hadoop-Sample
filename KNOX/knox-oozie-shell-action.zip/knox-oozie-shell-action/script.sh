echo 'I am startting the execution'
pwd
ls
echo 'Hello World'
#sleep 1m
echo 'I have Executed the Oozie script'

