#!/bin/bash
echo "`date` hi" > /tmp/output