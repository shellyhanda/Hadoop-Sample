echo 'I am startting'

echo 'i am sleeping'
#sleep 1m
echo 'I am finish'
